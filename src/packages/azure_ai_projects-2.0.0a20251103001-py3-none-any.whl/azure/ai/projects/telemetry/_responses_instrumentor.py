# ------------------------------------
# Copyright (c) Microsoft Corporation.
# Licensed under the MIT License.
# ------------------------------------
# pyright: reportPossiblyUnboundVariable=false
# pylint: disable=too-many-lines,line-too-long,useless-suppression,too-many-nested-blocks,docstring-missing-param,docstring-should-be-keyword,docstring-missing-return,docstring-missing-rtype,broad-exception-caught,logging-fstring-interpolation,unused-variable,unused-argument,protected-access,global-variable-not-assigned,global-statement
# Pylint disables are appropriate for this internal instrumentation class because:
# - Extensive documentation isn't required for internal methods (docstring-missing-*)
# - Broad exception catching is often necessary for telemetry (shouldn't break user code)
# - Protected access is needed for instrumentation to hook into client internals
# - Some unused variables/arguments exist for API compatibility and future extensibility
# - Global variables are used for metrics state management across instances
# - Line length and complexity limits are relaxed for instrumentation code
import functools
import json
import logging
import os
import time
from enum import Enum
from typing import Any, Callable, Dict, List, Optional, Tuple, TYPE_CHECKING
from urllib.parse import urlparse
from azure.core import CaseInsensitiveEnumMeta  # type: ignore
from azure.core.tracing import AbstractSpan
from ._utils import (
    GEN_AI_EVENT_CONTENT,
    GEN_AI_PROVIDER_NAME,
    GEN_AI_OPERATION_NAME,
    OperationName,
    start_span,
)

_Unset: Any = object()

logger = logging.getLogger(__name__)

try:  # pylint: disable=unused-import
    # pylint: disable = no-name-in-module
    from opentelemetry.trace import StatusCode
    from opentelemetry.metrics import get_meter

    _tracing_library_available = True
except ModuleNotFoundError:
    _tracing_library_available = False

if TYPE_CHECKING:
    pass

__all__ = [
    "ResponsesInstrumentor",
]

_responses_traces_enabled: bool = False
_trace_responses_content: bool = False

# Azure OpenAI system identifier for traces
AZURE_OPENAI_SYSTEM = "azure.openai"

# Metrics instruments
_operation_duration_histogram = None
_token_usage_histogram = None


class TraceType(str, Enum, metaclass=CaseInsensitiveEnumMeta):  # pylint: disable=C4747
    """An enumeration class to represent different types of traces."""

    RESPONSES = "Responses"
    CONVERSATIONS = "Conversations"


class ResponsesInstrumentor:
    """
    A class for managing the trace instrumentation of OpenAI Responses and Conversations APIs.

    This class allows enabling or disabling tracing for OpenAI Responses and Conversations API calls
    and provides functionality to check whether instrumentation is active.
    """

    def __init__(self):
        if not _tracing_library_available:
            logger.warning(
                "OpenTelemetry is not available. "
                "Please install opentelemetry-api and opentelemetry-sdk to enable tracing."
            )
        # We could support different semantic convention versions from the same library
        # and have a parameter that specifies the version to use.
        self._impl = _ResponsesInstrumentorPreview()

    def instrument(self, enable_content_recording: Optional[bool] = None) -> None:
        """
        Enable trace instrumentation for OpenAI Responses and Conversations APIs.

        :param enable_content_recording: Whether content recording is enabled as part
          of the traces or not. Content in this context refers to chat message content
          and function call tool related function names, function parameter names and
          values. `True` will enable content recording, `False` will disable it. If no value
          is provided, then the value read from environment variable
          OTEL_INSTRUMENTATION_GENAI_CAPTURE_MESSAGE_CONTENT is used. If the environment
          variable is not found, then the value will default to `False`.
          Please note that successive calls to instrument will always apply the content
          recording value provided with the most recent call to instrument (including
          applying the environment variable if no value is provided and defaulting to `False`
          if the environment variable is not found), even if instrument was already previously
          called without uninstrument being called in between the instrument calls.
        :type enable_content_recording: bool, optional
        """
        self._impl.instrument(enable_content_recording)

    def uninstrument(self) -> None:
        """
        Remove trace instrumentation for OpenAI Responses and Conversations APIs.

        This method removes any active instrumentation, stopping the tracing
        of OpenAI Responses and Conversations API methods.
        """
        self._impl.uninstrument()

    def is_instrumented(self) -> bool:
        """
        Check if trace instrumentation for OpenAI Responses and Conversations APIs is currently enabled.

        :return: True if instrumentation is active, False otherwise.
        :rtype: bool
        """
        return self._impl.is_instrumented()

    def is_content_recording_enabled(self) -> bool:
        """This function gets the content recording value.

        :return: A bool value indicating whether content recording is enabled.
        :rtype: bool
        """
        return self._impl.is_content_recording_enabled()


class _ResponsesInstrumentorPreview:  # pylint: disable=too-many-instance-attributes,too-many-statements,too-many-public-methods
    """
    A class for managing the trace instrumentation of OpenAI Responses API.

    This class allows enabling or disabling tracing for OpenAI Responses API calls
    and provides functionality to check whether instrumentation is active.
    """

    def _str_to_bool(self, s):
        if s is None:
            return False
        return str(s).lower() == "true"

    def _is_instrumentation_enabled(self) -> bool:
        """Check if instrumentation is enabled via environment variable.

        Returns True if AZURE_TRACING_GEN_AI_INSTRUMENT_RESPONSES_API is not set or is "true" (case insensitive).
        Returns False if the environment variable is set to any other value.
        """
        env_value = os.environ.get("AZURE_TRACING_GEN_AI_INSTRUMENT_RESPONSES_API")
        if env_value is None:
            return True  # Default to enabled if not specified
        return str(env_value).lower() == "true"

    def _initialize_metrics(self):
        """Initialize OpenTelemetry metrics instruments."""
        global _operation_duration_histogram, _token_usage_histogram  # pylint: disable=global-statement

        if not _tracing_library_available:
            return

        try:
            meter = get_meter(__name__)  # pyright: ignore [reportPossiblyUnboundVariable]

            # Operation duration histogram
            _operation_duration_histogram = meter.create_histogram(
                name="gen_ai.client.operation.duration", description="Duration of GenAI operations", unit="s"
            )

            # Token usage histogram
            _token_usage_histogram = meter.create_histogram(
                name="gen_ai.client.token.usage", description="Token usage for GenAI operations", unit="token"
            )

        except Exception as e:  # pylint: disable=broad-exception-caught
            logger.debug("Failed to initialize metrics: %s", e)

    def _record_operation_duration(
        self,
        duration: float,
        operation_name: str,
        server_address: Optional[str] = None,
        port: Optional[int] = None,
        model: Optional[str] = None,
        error_type: Optional[str] = None,
    ):
        """Record operation duration metrics."""
        global _operation_duration_histogram  # pylint: disable=global-variable-not-assigned

        if not _operation_duration_histogram:
            return

        attributes = {
            "gen_ai.operation.name": operation_name,
            GEN_AI_PROVIDER_NAME: AZURE_OPENAI_SYSTEM,
        }

        if server_address:
            attributes["server.address"] = server_address
        if port:
            attributes["server.port"] = str(port)
        if model:
            attributes["gen_ai.request.model"] = model
        if error_type:
            attributes["error.type"] = error_type

        try:
            _operation_duration_histogram.record(duration, attributes)
        except Exception as e:  # pylint: disable=broad-exception-caught
            logger.debug("Failed to record operation duration: %s", e)

    def _record_token_usage(
        self,
        token_count: int,
        token_type: str,
        operation_name: str,
        server_address: Optional[str] = None,
        model: Optional[str] = None,
    ):
        """Record token usage metrics."""
        global _token_usage_histogram  # pylint: disable=global-variable-not-assigned

        if not _token_usage_histogram:
            return

        attributes = {
            "gen_ai.operation.name": operation_name,
            GEN_AI_PROVIDER_NAME: AZURE_OPENAI_SYSTEM,
            "gen_ai.token.type": token_type,
        }

        if server_address:
            attributes["server.address"] = server_address
        if model:
            attributes["gen_ai.request.model"] = model

        try:
            _token_usage_histogram.record(token_count, attributes)
        except Exception as e:  # pylint: disable=broad-exception-caught
            logger.debug("Failed to record token usage: %s", e)

    def _record_token_metrics_from_response(
        self,
        response: Any,
        operation_name: str,
        server_address: Optional[str] = None,
        model: Optional[str] = None,
    ):
        """Extract and record token usage metrics from response."""
        try:
            if hasattr(response, "usage"):
                usage = response.usage
                if hasattr(usage, "prompt_tokens") and usage.prompt_tokens:
                    self._record_token_usage(usage.prompt_tokens, "input", operation_name, server_address, model)
                if hasattr(usage, "completion_tokens") and usage.completion_tokens:
                    self._record_token_usage(
                        usage.completion_tokens, "completion", operation_name, server_address, model
                    )
        except Exception as e:  # pylint: disable=broad-exception-caught
            logger.debug("Failed to extract token metrics from response: %s", e)

    def _record_metrics(  # pylint: disable=docstring-missing-type
        self,
        operation_type: str,
        duration: float,
        result: Any = None,
        span_attributes: Optional[Dict[str, Any]] = None,
        error_type: Optional[str] = None,
    ):
        """
        Record comprehensive metrics for different API operation types.

        :param operation_type: Type of operation ("responses", "conversation", "conversation_items")
        :param duration: Operation duration in seconds
        :param result: API response object for extracting response-specific attributes
        :param span_attributes: Dictionary of span attributes to extract relevant metrics from
        :param error_type: Error type if an error occurred
        """
        try:
            # Build base attributes - always included
            if operation_type == "responses":
                operation_name = "responses"
            elif operation_type == "conversation":
                operation_name = "create_conversation"
            elif operation_type == "conversation_items":
                operation_name = "list_conversation_items"
            else:
                operation_name = operation_type

            # Extract relevant attributes from span_attributes if provided
            server_address = None
            server_port = None
            request_model = None

            if span_attributes:
                server_address = span_attributes.get("server.address")
                server_port = span_attributes.get("server.port")
                request_model = span_attributes.get("gen_ai.request.model")

            # Extract response-specific attributes from result if provided
            response_model = None

            if result:
                response_model = getattr(result, "model", None)
                # service_tier = getattr(result, "service_tier", None)  # Unused

            # Use response model if available, otherwise fall back to request model
            model_for_metrics = response_model or request_model

            # Record operation duration with relevant attributes
            self._record_operation_duration(
                duration=duration,
                operation_name=operation_name,
                server_address=server_address,
                port=server_port,
                model=model_for_metrics,
                error_type=error_type,
            )

            # Record token usage metrics if result has usage information
            if result and hasattr(result, "usage"):
                usage = result.usage
                if hasattr(usage, "prompt_tokens") and usage.prompt_tokens:
                    self._record_token_usage(
                        token_count=usage.prompt_tokens,
                        token_type="input",
                        operation_name=operation_name,
                        server_address=server_address,
                        model=model_for_metrics,
                    )
                if hasattr(usage, "completion_tokens") and usage.completion_tokens:
                    self._record_token_usage(
                        token_count=usage.completion_tokens,
                        token_type="completion",
                        operation_name=operation_name,
                        server_address=server_address,
                        model=model_for_metrics,
                    )
                # Handle Responses API specific token fields
                if hasattr(usage, "input_tokens") and usage.input_tokens:
                    self._record_token_usage(
                        token_count=usage.input_tokens,
                        token_type="input",
                        operation_name=operation_name,
                        server_address=server_address,
                        model=model_for_metrics,
                    )
                if hasattr(usage, "output_tokens") and usage.output_tokens:
                    self._record_token_usage(
                        token_count=usage.output_tokens,
                        token_type="completion",
                        operation_name=operation_name,
                        server_address=server_address,
                        model=model_for_metrics,
                    )

        except Exception as e:  # pylint: disable=broad-exception-caught
            logger.debug("Failed to record metrics for %s: %s", operation_type, e)

    def instrument(self, enable_content_recording: Optional[bool] = None):
        """
        Enable trace instrumentation for OpenAI Responses API.

        :param enable_content_recording: Whether content recording is enabled as part
          of the traces or not. Content in this context refers to chat message content
          and function call tool related function names, function parameter names and
          values. `True` will enable content recording, `False` will disable it. If no value
          is provided, then the value read from environment variable
          OTEL_INSTRUMENTATION_GENAI_CAPTURE_MESSAGE_CONTENT is used. If the environment
          variable is not found, then the value will default to `False`.
          Please note that successive calls to instrument will always apply the content
          recording value provided with the most recent call to instrument (including
          applying the environment variable if no value is provided and defaulting to `False`
          if the environment variable is not found), even if instrument was already previously
          called without uninstrument being called in between the instrument calls.
        :type enable_content_recording: bool, optional
        """
        # Check if instrumentation is enabled via environment variable
        if not self._is_instrumentation_enabled():
            return  # No-op if instrumentation is disabled

        if enable_content_recording is None:
            enable_content_recording = self._str_to_bool(
                os.environ.get("OTEL_INSTRUMENTATION_GENAI_CAPTURE_MESSAGE_CONTENT", "false")
            )

        if not self.is_instrumented():
            self._instrument_responses(enable_content_recording)
        else:
            self.set_enable_content_recording(enable_content_recording)

    def uninstrument(self):
        """
        Disable trace instrumentation for OpenAI Responses API.

        This method removes any active instrumentation, stopping the tracing
        of OpenAI Responses API calls.
        """
        if self.is_instrumented():
            self._uninstrument_responses()

    def is_instrumented(self):
        """
        Check if trace instrumentation for OpenAI Responses API is currently enabled.

        :return: True if instrumentation is active, False otherwise.
        :rtype: bool
        """
        return self._is_instrumented()

    def set_enable_content_recording(self, enable_content_recording: bool = False) -> None:
        """This function sets the content recording value.

        :param enable_content_recording: Indicates whether tracing of message content should be enabled.
                                    This also controls whether function call tool function names,
                                    parameter names and parameter values are traced.
        :type enable_content_recording: bool
        """
        self._set_enable_content_recording(enable_content_recording=enable_content_recording)

    def is_content_recording_enabled(self) -> bool:
        """This function gets the content recording value.

        :return: A bool value indicating whether content tracing is enabled.
        :rtype bool
        """
        return self._is_content_recording_enabled()

    def _set_attributes(self, span: "AbstractSpan", *attrs: Tuple[str, Any]) -> None:
        for attr in attrs:
            span.add_attribute(attr[0], attr[1])

    def _set_span_attribute_safe(self, span: "AbstractSpan", key: str, value: Any) -> None:
        """Safely set a span attribute only if the value is meaningful."""
        if not span or not span.span_instance.is_recording:
            return

        # Only set attribute if value exists and is meaningful
        if value is not None and value != "" and value != []:
            span.add_attribute(key, value)

    def _parse_url(self, url):
        parsed = urlparse(url)
        server_address = parsed.hostname
        port = parsed.port
        return server_address, port

    def _create_event_attributes(
        self,
        conversation_id: Optional[str] = None,  # pylint: disable=unused-argument
        message_role: Optional[str] = None,
    ) -> Dict[str, Any]:
        attrs: Dict[str, Any] = {GEN_AI_PROVIDER_NAME: AZURE_OPENAI_SYSTEM}
        # Removed conversation_id from event attributes as requested - it's redundant
        # if conversation_id:
        #     attrs["gen_ai.conversation.id"] = conversation_id
        if message_role:
            attrs["gen_ai.message.role"] = message_role
        return attrs

    def _add_message_event(
        self,
        span: "AbstractSpan",
        role: str,
        content: Optional[str] = None,
        conversation_id: Optional[str] = None,
    ) -> None:
        """Add a message event to the span."""
        event_body: Dict[str, Any] = {"role": role}

        if _trace_responses_content and content:
            event_body["content"] = content

        attributes = self._create_event_attributes(
            conversation_id=conversation_id,
            message_role=role,
        )
        # Always use JSON format but only include content when recording is enabled
        attributes[GEN_AI_EVENT_CONTENT] = json.dumps(event_body, ensure_ascii=False)

        event_name = f"gen_ai.{role}.message"
        span.span_instance.add_event(name=event_name, attributes=attributes)

    def start_responses_span(
        self,
        server_address: Optional[str] = None,
        port: Optional[int] = None,
        model: Optional[str] = None,
        assistant_name: Optional[str] = None,
        conversation_id: Optional[str] = None,
        input_text: Optional[str] = None,
        stream: bool = False,  # pylint: disable=unused-argument
    ) -> "Optional[AbstractSpan]":
        """Start a span for responses API call."""
        # Build span name: prefer model, then assistant name, then just operation
        if model:
            span_name = f"{OperationName.RESPONSES.value} {model}"
        elif assistant_name:
            span_name = f"{OperationName.RESPONSES.value} {assistant_name}"
        else:
            span_name = OperationName.RESPONSES.value

        span = start_span(
            operation_name=OperationName.RESPONSES,
            server_address=server_address,
            port=port,
            span_name=span_name,
            model=model,
            gen_ai_provider=AZURE_OPENAI_SYSTEM,
        )

        if span and span.span_instance.is_recording:
            # Set operation name attribute (start_span doesn't set this automatically)
            self._set_attributes(
                span,
                (GEN_AI_OPERATION_NAME, OperationName.RESPONSES.value),
            )

            # Set response-specific attributes that start_span doesn't handle
            # Note: model and server_address are already set by start_span, so we don't need to set them again
            self._set_span_attribute_safe(span, "gen_ai.conversation.id", conversation_id)
            self._set_span_attribute_safe(span, "gen_ai.request.assistant_name", assistant_name)

            # Add user message event if content recording is enabled
            if input_text:
                self._add_message_event(
                    span,
                    role="user",
                    content=input_text,
                    conversation_id=conversation_id,
                )

        return span

    def _extract_server_info_from_client(
        self, client: Any
    ) -> Tuple[Optional[str], Optional[int]]:  # pylint: disable=docstring-missing-return,docstring-missing-rtype
        """Extract server address and port from OpenAI client."""
        try:
            # First try direct access to base_url
            if hasattr(client, "base_url") and client.base_url:
                return self._parse_url(str(client.base_url))
            if hasattr(client, "_base_url") and client._base_url:  # pylint: disable=protected-access
                return self._parse_url(str(client._base_url))

            # Try the nested client structure as suggested
            base_client = getattr(client, "_client", None)
            if base_client:
                base_url = getattr(base_client, "base_url", None)
                if base_url:
                    return self._parse_url(str(base_url))
        except Exception:  # pylint: disable=broad-exception-caught
            pass
        return None, None

    def _extract_conversation_id(self, kwargs: Dict[str, Any]) -> Optional[str]:
        """Extract conversation ID from kwargs."""
        return kwargs.get("conversation") or kwargs.get("conversation_id")

    def _extract_model(self, kwargs: Dict[str, Any]) -> Optional[str]:
        """Extract model from kwargs."""
        return kwargs.get("model")

    def _extract_assistant_name(self, kwargs: Dict[str, Any]) -> Optional[str]:
        """Extract assistant/agent name from kwargs."""
        extra_body = kwargs.get("extra_body")
        if extra_body and isinstance(extra_body, dict):
            agent_info = extra_body.get("agent")
            if agent_info and isinstance(agent_info, dict):
                return agent_info.get("name")
        return None

    def _extract_input_text(self, kwargs: Dict[str, Any]) -> Optional[str]:
        """Extract input text from kwargs."""
        return kwargs.get("input")

    def _extract_output_text(self, response: Any) -> Optional[str]:
        """Extract output text from response."""
        if hasattr(response, "output") and response.output:
            # Handle simple string output (for tests/simple cases)
            if isinstance(response.output, str):
                return response.output

            # Handle complex output structure (list of response messages)
            output_texts = []
            try:
                for output_item in response.output:
                    if hasattr(output_item, "content") and output_item.content:
                        # content is typically a list of content blocks
                        for content_block in output_item.content:
                            if hasattr(content_block, "text"):
                                output_texts.append(content_block.text)
                            elif hasattr(content_block, "output_text") and hasattr(content_block.output_text, "text"):
                                # Handle ResponseOutputText structure
                                output_texts.append(content_block.output_text.text)
                            elif isinstance(content_block, str):
                                output_texts.append(content_block)
                    elif isinstance(output_item, str):
                        # Handle simple string items
                        output_texts.append(output_item)

                if output_texts:
                    return " ".join(output_texts)
            except (AttributeError, TypeError):
                # Fallback: convert to string but log for debugging
                logger.debug(
                    "Failed to extract structured output text, falling back to string conversion: %s", response.output
                )
                return str(response.output)
        return None

    def _extract_responses_api_attributes(self, span: "AbstractSpan", response: Any) -> None:
        """Extract and set attributes for Responses API responses."""
        try:
            # Extract and set response model
            model = getattr(response, "model", None)
            self._set_span_attribute_safe(span, "gen_ai.response.model", model)

            # Extract and set response ID
            response_id = getattr(response, "id", None)
            self._set_span_attribute_safe(span, "gen_ai.response.id", response_id)

            # Extract and set system fingerprint if available
            system_fingerprint = getattr(response, "system_fingerprint", None)
            self._set_span_attribute_safe(span, "gen_ai.openai.response.system_fingerprint", system_fingerprint)

            # Extract and set usage information (Responses API may use input_tokens/output_tokens)
            usage = getattr(response, "usage", None)
            if usage:
                # Try input_tokens first, then prompt_tokens for compatibility
                input_tokens = getattr(usage, "input_tokens", None) or getattr(usage, "prompt_tokens", None)
                # Try output_tokens first, then completion_tokens for compatibility
                output_tokens = getattr(usage, "output_tokens", None) or getattr(usage, "completion_tokens", None)
                # total_tokens = getattr(usage, "total_tokens", None)  # Unused

                self._set_span_attribute_safe(span, "gen_ai.usage.input_tokens", input_tokens)
                self._set_span_attribute_safe(span, "gen_ai.usage.output_tokens", output_tokens)
                # self._set_span_attribute_safe(span, "gen_ai.usage.total_tokens", total_tokens)  # Commented out as redundant

            # Extract finish reasons from output items (Responses API structure)
            output = getattr(response, "output", None)
            if output:
                finish_reasons = []
                for item in output:
                    if hasattr(item, "finish_reason") and item.finish_reason:
                        finish_reasons.append(item.finish_reason)

                if finish_reasons:
                    self._set_span_attribute_safe(span, "gen_ai.response.finish_reasons", finish_reasons)
            else:
                # Handle single finish reason (not in output array)
                finish_reason = getattr(response, "finish_reason", None)
                if finish_reason:
                    self._set_span_attribute_safe(span, "gen_ai.response.finish_reasons", [finish_reason])

        except Exception as e:
            logger.debug(f"Error extracting responses API attributes: {e}")

    def _extract_conversation_attributes(self, span: "AbstractSpan", response: Any) -> None:
        """Extract and set attributes for conversation creation responses."""
        try:
            # Extract and set conversation ID
            conversation_id = getattr(response, "id", None)
            self._set_span_attribute_safe(span, "gen_ai.conversation.id", conversation_id)

            # Set response object type
            # self._set_span_attribute_safe(span, "gen_ai.response.object", "conversation")

        except Exception as e:
            logger.debug(f"Error extracting conversation attributes: {e}")

    def _extract_conversation_items_attributes(
        self, span: "AbstractSpan", response: Any, args: Tuple, kwargs: Dict[str, Any]
    ) -> None:
        """Extract and set attributes for conversation items list responses."""
        try:
            # Set response object type for list operations
            # self._set_span_attribute_safe(span, "gen_ai.response.object", "list")

            # Extract conversation_id from request parameters
            conversation_id = None
            if args and len(args) > 1:
                # Second argument might be conversation_id
                conversation_id = args[1]
            elif "conversation_id" in kwargs:
                conversation_id = kwargs["conversation_id"]

            if conversation_id:
                self._set_span_attribute_safe(span, "gen_ai.conversation.id", conversation_id)

            # Note: Removed gen_ai.response.has_more attribute as requested

        except Exception as e:
            logger.debug(f"Error extracting conversation items attributes: {e}")

    def _extract_response_attributes(self, response: Any) -> Dict[str, Any]:
        """Extract response attributes from response object (legacy method for backward compatibility)."""
        attributes = {}

        try:
            # Extract response model
            model = getattr(response, "model", None)
            if model:
                attributes["gen_ai.response.model"] = model

            # Extract response ID
            response_id = getattr(response, "id", None)
            if response_id:
                attributes["gen_ai.response.id"] = response_id

            # Extract usage information
            usage = getattr(response, "usage", None)
            if usage:
                prompt_tokens = getattr(usage, "prompt_tokens", None)
                completion_tokens = getattr(usage, "completion_tokens", None)
                # total_tokens = getattr(usage, "total_tokens", None)  # Unused

                if prompt_tokens:
                    attributes["gen_ai.usage.input_tokens"] = prompt_tokens
                if completion_tokens:
                    attributes["gen_ai.usage.output_tokens"] = completion_tokens
                # if total_tokens:
                #     attributes["gen_ai.usage.total_tokens"] = total_tokens  # Commented out as redundant

            # Extract finish reasons from output items (Responses API structure)
            output = getattr(response, "output", None)
            if output:
                finish_reasons = []
                for item in output:
                    if hasattr(item, "finish_reason") and item.finish_reason:
                        finish_reasons.append(item.finish_reason)

                if finish_reasons:
                    attributes["gen_ai.response.finish_reasons"] = finish_reasons
            else:
                finish_reason = getattr(response, "finish_reason", None)
                if finish_reason:
                    attributes["gen_ai.response.finish_reasons"] = [finish_reason]

        except Exception as e:
            logger.debug(f"Error extracting response attributes: {e}")

        return attributes

    def _create_responses_span_from_parameters(self, *args, **kwargs):
        """Extract parameters and create span for responses API tracing."""
        # Extract client from args (first argument)
        client = args[0] if args else None
        server_address, port = self._extract_server_info_from_client(client)

        # Extract parameters from kwargs
        conversation_id = self._extract_conversation_id(kwargs)
        model = self._extract_model(kwargs)
        assistant_name = self._extract_assistant_name(kwargs)
        input_text = self._extract_input_text(kwargs)
        stream = kwargs.get("stream", False)

        # Create and return the span
        return self.start_responses_span(
            server_address=server_address,
            port=port,
            model=model,
            assistant_name=assistant_name,
            conversation_id=conversation_id,
            input_text=input_text,
            stream=stream,
        )

    def trace_responses_create(self, function, *args, **kwargs):
        """Trace synchronous responses.create calls."""
        span = self._create_responses_span_from_parameters(*args, **kwargs)

        # Extract parameters for metrics
        server_address, port = self._extract_server_info_from_client(args[0] if args else None)
        model = self._extract_model(kwargs)
        operation_name = "responses"

        start_time = time.time()

        if span is None:
            # Still record metrics even without spans
            try:
                result = function(*args, **kwargs)
                duration = time.time() - start_time
                span_attributes = {
                    "gen_ai.request.model": model,
                    "server.address": server_address,
                    "server.port": port,
                }
                self._record_metrics(
                    operation_type="responses",
                    duration=duration,
                    result=result,
                    span_attributes=span_attributes,
                )
                return result
            except Exception as e:
                duration = time.time() - start_time
                span_attributes = {
                    "gen_ai.request.model": model,
                    "server.address": server_address,
                    "server.port": port,
                }
                self._record_metrics(
                    operation_type="responses",
                    duration=duration,
                    result=None,
                    span_attributes=span_attributes,
                    error_type=str(type(e).__name__),
                )
                raise

        # Handle streaming vs non-streaming responses differently
        stream = kwargs.get("stream", False)
        if stream:
            # For streaming, don't use context manager - let wrapper handle span lifecycle
            try:
                result = function(*args, **kwargs)
                result = self._wrap_streaming_response(
                    result, span, kwargs, start_time, operation_name, server_address, port, model
                )
                return result
            except Exception as e:
                duration = time.time() - start_time
                span_attributes = {
                    "gen_ai.request.model": model,
                    "server.address": server_address,
                    "server.port": port,
                }
                self._record_metrics(
                    operation_type="responses",
                    duration=duration,
                    result=None,
                    span_attributes=span_attributes,
                    error_type=str(type(e).__name__),
                )
                self.record_error(span, e)
                span.span_instance.end()
                raise
        else:
            # For non-streaming, use context manager as before
            with span:
                try:
                    result = function(*args, **kwargs)
                    duration = time.time() - start_time

                    # Extract and set response attributes
                    self._extract_responses_api_attributes(span, result)

                    # Add assistant message event
                    output_text = self._extract_output_text(result)
                    if output_text:
                        conversation_id = self._extract_conversation_id(kwargs)
                        self._add_message_event(
                            span,
                            role="assistant",
                            content=output_text,
                            conversation_id=conversation_id,
                        )

                    # Record metrics using new dedicated method
                    span_attributes = {
                        "gen_ai.request.model": model,
                        "server.address": server_address,
                        "server.port": port,
                    }
                    self._record_metrics(
                        operation_type="responses",
                        duration=duration,
                        result=result,
                        span_attributes=span_attributes,
                    )
                    # pyright: ignore [reportPossiblyUnboundVariable]
                    span.span_instance.set_status(StatusCode.OK)
                except Exception as e:
                    duration = time.time() - start_time
                    span_attributes = {
                        "gen_ai.request.model": model,
                        "server.address": server_address,
                        "server.port": port,
                    }
                    self._record_metrics(
                        operation_type="responses",
                        duration=duration,
                        result=None,
                        span_attributes=span_attributes,
                        error_type=str(type(e).__name__),
                    )
                    span.span_instance.set_status(
                        # pyright: ignore [reportPossiblyUnboundVariable]
                        StatusCode.ERROR,
                        str(e),
                    )
                    span.span_instance.record_exception(e)
                    raise
            return result

    async def trace_responses_create_async(self, function, *args, **kwargs):
        """Trace asynchronous responses.create calls."""
        span = self._create_responses_span_from_parameters(*args, **kwargs)

        # Extract parameters for metrics
        server_address, port = self._extract_server_info_from_client(args[0] if args else None)
        model = self._extract_model(kwargs)
        operation_name = "responses"

        start_time = time.time()

        if span is None:
            # Still record metrics even without spans
            try:
                result = await function(*args, **kwargs)
                duration = time.time() - start_time
                span_attributes = {
                    "gen_ai.request.model": model,
                    "server.address": server_address,
                    "server.port": port,
                }
                self._record_metrics(
                    operation_type="responses",
                    duration=duration,
                    result=result,
                    span_attributes=span_attributes,
                )
                return result
            except Exception as e:
                duration = time.time() - start_time
                span_attributes = {
                    "gen_ai.request.model": model,
                    "server.address": server_address,
                    "server.port": port,
                }
                self._record_metrics(
                    operation_type="responses",
                    duration=duration,
                    result=None,
                    span_attributes=span_attributes,
                    error_type=str(type(e).__name__),
                )
                raise

        # Handle streaming vs non-streaming responses differently
        stream = kwargs.get("stream", False)
        if stream:
            # For streaming, don't use context manager - let wrapper handle span lifecycle
            try:
                result = await function(*args, **kwargs)
                result = self._wrap_async_streaming_response(
                    result, span, kwargs, start_time, operation_name, server_address, port, model
                )
                return result
            except Exception as e:
                duration = time.time() - start_time
                span_attributes = {
                    "gen_ai.request.model": model,
                    "server.address": server_address,
                    "server.port": port,
                }
                self._record_metrics(
                    operation_type="responses",
                    duration=duration,
                    result=None,
                    span_attributes=span_attributes,
                    error_type=str(type(e).__name__),
                )
                self.record_error(span, e)
                span.span_instance.end()
                raise
        else:
            # For non-streaming, use context manager as before
            with span:
                try:
                    result = await function(*args, **kwargs)
                    duration = time.time() - start_time

                    # Extract and set response attributes
                    self._extract_responses_api_attributes(span, result)

                    # Add assistant message event
                    output_text = self._extract_output_text(result)
                    if output_text:
                        conversation_id = self._extract_conversation_id(kwargs)
                        self._add_message_event(
                            span,
                            role="assistant",
                            content=output_text,
                            conversation_id=conversation_id,
                        )

                    # Record metrics using new dedicated method
                    span_attributes = {
                        "gen_ai.request.model": model,
                        "server.address": server_address,
                        "server.port": port,
                    }
                    self._record_metrics(
                        operation_type="responses",
                        duration=duration,
                        result=result,
                        span_attributes=span_attributes,
                    )
                    # pyright: ignore [reportPossiblyUnboundVariable]
                    span.span_instance.set_status(StatusCode.OK)
                except Exception as e:
                    duration = time.time() - start_time
                    span_attributes = {
                        "gen_ai.request.model": model,
                        "server.address": server_address,
                        "server.port": port,
                    }
                    self._record_metrics(
                        operation_type="responses",
                        duration=duration,
                        result=None,
                        span_attributes=span_attributes,
                        error_type=str(type(e).__name__),
                    )
                    span.span_instance.set_status(
                        # pyright: ignore [reportPossiblyUnboundVariable]
                        StatusCode.ERROR,
                        str(e),
                    )
                    span.span_instance.record_exception(e)
                    raise
            return result

    def _wrap_streaming_response(
        self,
        stream,
        span: "AbstractSpan",
        original_kwargs: Dict[str, Any],
        start_time: float,
        operation_name: str,
        server_address: Optional[str],
        port: Optional[int],
        model: Optional[str],
    ):
        """Wrap a streaming response to trace chunks."""
        conversation_id = self._extract_conversation_id(original_kwargs)
        instrumentor = self  # Capture the instrumentor instance

        class StreamWrapper:  # pylint: disable=too-many-instance-attributes,protected-access
            def __init__(
                self,
                stream_iter,
                span,
                conversation_id,
                instrumentor,
                start_time,
                operation_name,
                server_address,
                port,
                model,
            ):
                self.stream_iter = stream_iter
                self.span = span
                self.conversation_id = conversation_id
                self.instrumentor = instrumentor
                self.accumulated_content = []
                self.span_ended = False
                self.start_time = start_time
                self.operation_name = operation_name
                self.server_address = server_address
                self.port = port
                self.model = model

                # Enhanced properties for sophisticated chunk processing
                self.accumulated_output = []
                self.response_id = None
                self.response_model = None
                self.service_tier = None
                self.input_tokens = 0
                self.output_tokens = 0

            def append_output_content(self, content):
                """Append content to accumulated output list."""
                if content:
                    self.accumulated_output.append(str(content))

            def set_response_metadata(self, chunk):
                """Update response metadata from chunk if not already set."""
                if not self.response_id:
                    self.response_id = getattr(chunk, "id", None)
                if not self.response_model:
                    self.response_model = getattr(chunk, "model", None)
                if not self.service_tier:
                    self.service_tier = getattr(chunk, "service_tier", None)

            def process_chunk(self, chunk):
                """Process chunk to accumulate data and update metadata."""
                # Detect ResponseTextDeltaEvent format
                if hasattr(chunk, "delta") and isinstance(chunk.delta, str):
                    self.append_output_content(chunk.delta)
                # Detect standard Responses API format
                elif hasattr(chunk, "output") and chunk.output:
                    self.append_output_content(chunk.output)

                # Always update metadata
                self.set_response_metadata(chunk)

                # Handle usage info
                usage = getattr(chunk, "usage", None)
                if usage:
                    if hasattr(usage, "input_tokens") and usage.input_tokens:
                        self.input_tokens += usage.input_tokens
                    if hasattr(usage, "output_tokens") and usage.output_tokens:
                        self.output_tokens += usage.output_tokens
                    # Also handle standard token field names
                    if hasattr(usage, "prompt_tokens") and usage.prompt_tokens:
                        self.input_tokens += usage.prompt_tokens
                    if hasattr(usage, "completion_tokens") and usage.completion_tokens:
                        self.output_tokens += usage.completion_tokens

            def cleanup(self):
                """Perform final cleanup when streaming is complete."""
                if not self.span_ended:
                    duration = time.time() - self.start_time

                    # Join all accumulated output content
                    complete_content = "".join(self.accumulated_output)

                    if self.span.span_instance.is_recording:
                        # Always add assistant message event (content determined by _add_message_event)
                        self.instrumentor._add_message_event(
                            self.span,
                            role="assistant",
                            content=complete_content,
                            conversation_id=self.conversation_id,
                        )

                        # Set final span attributes using accumulated metadata
                        if self.response_id:
                            self.instrumentor._set_span_attribute_safe(
                                self.span, "gen_ai.response.id", self.response_id
                            )
                        if self.response_model:
                            self.instrumentor._set_span_attribute_safe(
                                self.span, "gen_ai.response.model", self.response_model
                            )
                        if self.service_tier:
                            self.instrumentor._set_span_attribute_safe(
                                self.span, "gen_ai.openai.response.service_tier", self.service_tier
                            )

                        # Set token usage span attributes
                        if self.input_tokens > 0:
                            self.instrumentor._set_span_attribute_safe(
                                self.span, "gen_ai.usage.prompt_tokens", self.input_tokens
                            )
                        if self.output_tokens > 0:
                            self.instrumentor._set_span_attribute_safe(
                                self.span, "gen_ai.usage.completion_tokens", self.output_tokens
                            )

                    # Record metrics using accumulated data
                    span_attributes = {
                        "gen_ai.request.model": self.model,
                        "server.address": self.server_address,
                        "server.port": self.port,
                    }

                    # Create mock result object with accumulated data for metrics
                    class MockResult:
                        def __init__(self, response_id, response_model, service_tier, input_tokens, output_tokens):
                            self.id = response_id
                            self.model = response_model
                            self.service_tier = service_tier
                            if input_tokens > 0 or output_tokens > 0:
                                self.usage = type(
                                    "Usage",
                                    (),
                                    {
                                        "input_tokens": input_tokens,
                                        "output_tokens": output_tokens,
                                        "prompt_tokens": input_tokens,
                                        "completion_tokens": output_tokens,
                                    },
                                )()

                    mock_result = MockResult(
                        self.response_id, self.response_model, self.service_tier, self.input_tokens, self.output_tokens
                    )

                    self.instrumentor._record_metrics(
                        operation_type="responses",
                        duration=duration,
                        result=mock_result,
                        span_attributes=span_attributes,
                    )

                    # End span with proper status
                    if self.span.span_instance.is_recording:
                        self.span.span_instance.set_status(
                            # pyright: ignore [reportPossiblyUnboundVariable]
                            StatusCode.OK
                        )
                        self.span.span_instance.end()
                    self.span_ended = True

            def __iter__(self):
                return self

            def __next__(self):
                try:
                    chunk = next(self.stream_iter)
                    # Process chunk to accumulate data and maintain API compatibility
                    self.process_chunk(chunk)
                    # Also maintain backward compatibility with old accumulated_content
                    if hasattr(chunk, "output") and chunk.output:
                        self.accumulated_content.append(str(chunk.output))
                    elif hasattr(chunk, "delta") and isinstance(chunk.delta, str):
                        self.accumulated_content.append(chunk.delta)
                    return chunk
                except StopIteration:
                    # Stream is finished, perform cleanup
                    self.cleanup()
                    raise
                except Exception as e:
                    # Error occurred, record metrics and set error status
                    if not self.span_ended:
                        duration = time.time() - self.start_time
                        span_attributes = {
                            "gen_ai.request.model": self.model,
                            "server.address": self.server_address,
                            "server.port": self.port,
                        }
                        self.instrumentor._record_metrics(
                            operation_type="responses",
                            duration=duration,
                            result=None,
                            span_attributes=span_attributes,
                            error_type=str(type(e).__name__),
                        )
                        if self.span.span_instance.is_recording:
                            self.span.span_instance.set_status(
                                # pyright: ignore [reportPossiblyUnboundVariable]
                                StatusCode.ERROR,
                                str(e),
                            )
                            self.span.span_instance.record_exception(e)
                            self.span.span_instance.end()
                        self.span_ended = True
                    raise

            def _finalize_span(self):
                """Finalize the span with accumulated content and end it."""
                if not self.span_ended:
                    duration = time.time() - self.start_time
                    span_attributes = {
                        "gen_ai.request.model": self.model,
                        "server.address": self.server_address,
                        "server.port": self.port,
                    }
                    self.instrumentor._record_metrics(
                        operation_type="responses",
                        duration=duration,
                        result=None,
                        span_attributes=span_attributes,
                    )

                    if self.span.span_instance.is_recording:
                        # Note: For streaming responses, response metadata like tokens, finish_reasons
                        # are typically not available in individual chunks, so we focus on content.

                        if self.accumulated_content:
                            full_content = "".join(self.accumulated_content)
                            self.instrumentor._add_message_event(
                                self.span,
                                role="assistant",
                                content=full_content,
                                conversation_id=self.conversation_id,
                            )
                        self.span.span_instance.set_status(
                            # pyright: ignore [reportPossiblyUnboundVariable]
                            StatusCode.OK
                        )
                        self.span.span_instance.end()
                    self.span_ended = True

            def __enter__(self):
                return self

            def __exit__(self, exc_type, exc_val, exc_tb):
                try:
                    self.cleanup()
                except Exception:
                    pass  # Don't let cleanup exceptions mask the original exception
                return False

        return StreamWrapper(
            stream, span, conversation_id, instrumentor, start_time, operation_name, server_address, port, model
        )

    def _wrap_async_streaming_response(
        self,
        stream,
        span: "AbstractSpan",
        original_kwargs: Dict[str, Any],
        start_time: float,
        operation_name: str,
        server_address: Optional[str],
        port: Optional[int],
        model: Optional[str],
    ):
        """Wrap an async streaming response to trace chunks."""
        conversation_id = self._extract_conversation_id(original_kwargs)

        class AsyncStreamWrapper:  # pylint: disable=too-many-instance-attributes,protected-access
            def __init__(
                self,
                stream_async_iter,
                span,
                conversation_id,
                instrumentor,
                start_time,
                operation_name,
                server_address,
                port,
                model,
            ):
                self.stream_async_iter = stream_async_iter
                self.span = span
                self.conversation_id = conversation_id
                self.instrumentor = instrumentor
                self.accumulated_content = []
                self.span_ended = False
                self.start_time = start_time
                self.operation_name = operation_name
                self.server_address = server_address
                self.port = port
                self.model = model

                # Enhanced properties for sophisticated chunk processing
                self.accumulated_output = []
                self.response_id = None
                self.response_model = None
                self.service_tier = None
                self.input_tokens = 0
                self.output_tokens = 0

            def append_output_content(self, content):
                """Append content to accumulated output list."""
                if content:
                    self.accumulated_output.append(str(content))

            def set_response_metadata(self, chunk):
                """Update response metadata from chunk if not already set."""
                if not self.response_id:
                    self.response_id = getattr(chunk, "id", None)
                if not self.response_model:
                    self.response_model = getattr(chunk, "model", None)
                if not self.service_tier:
                    self.service_tier = getattr(chunk, "service_tier", None)

            def process_chunk(self, chunk):
                """Process chunk to accumulate data and update metadata."""
                # Detect ResponseTextDeltaEvent format
                if hasattr(chunk, "delta") and isinstance(chunk.delta, str):
                    self.append_output_content(chunk.delta)
                # Detect standard Responses API format
                elif hasattr(chunk, "output") and chunk.output:
                    self.append_output_content(chunk.output)

                # Always update metadata
                self.set_response_metadata(chunk)

                # Handle usage info
                usage = getattr(chunk, "usage", None)
                if usage:
                    if hasattr(usage, "input_tokens") and usage.input_tokens:
                        self.input_tokens += usage.input_tokens
                    if hasattr(usage, "output_tokens") and usage.output_tokens:
                        self.output_tokens += usage.output_tokens
                    # Also handle standard token field names
                    if hasattr(usage, "prompt_tokens") and usage.prompt_tokens:
                        self.input_tokens += usage.prompt_tokens
                    if hasattr(usage, "completion_tokens") and usage.completion_tokens:
                        self.output_tokens += usage.completion_tokens

            def cleanup(self):
                """Perform final cleanup when streaming is complete."""
                if not self.span_ended:
                    duration = time.time() - self.start_time

                    # Join all accumulated output content
                    complete_content = "".join(self.accumulated_output)

                    if self.span.span_instance.is_recording:
                        # Always add assistant message event (content determined by _add_message_event)
                        self.instrumentor._add_message_event(
                            self.span,
                            role="assistant",
                            content=complete_content,
                            conversation_id=self.conversation_id,
                        )

                        # Set final span attributes using accumulated metadata
                        if self.response_id:
                            self.instrumentor._set_span_attribute_safe(
                                self.span, "gen_ai.response.id", self.response_id
                            )
                        if self.response_model:
                            self.instrumentor._set_span_attribute_safe(
                                self.span, "gen_ai.response.model", self.response_model
                            )
                        if self.service_tier:
                            self.instrumentor._set_span_attribute_safe(
                                self.span, "gen_ai.openai.response.service_tier", self.service_tier
                            )

                        # Set token usage span attributes
                        if self.input_tokens > 0:
                            self.instrumentor._set_span_attribute_safe(
                                self.span, "gen_ai.usage.prompt_tokens", self.input_tokens
                            )
                        if self.output_tokens > 0:
                            self.instrumentor._set_span_attribute_safe(
                                self.span, "gen_ai.usage.completion_tokens", self.output_tokens
                            )

                    # Record metrics using accumulated data
                    span_attributes = {
                        "gen_ai.request.model": self.model,
                        "server.address": self.server_address,
                        "server.port": self.port,
                    }

                    # Create mock result object with accumulated data for metrics
                    class MockResult:
                        def __init__(self, response_id, response_model, service_tier, input_tokens, output_tokens):
                            self.id = response_id
                            self.model = response_model
                            self.service_tier = service_tier
                            if input_tokens > 0 or output_tokens > 0:
                                self.usage = type(
                                    "Usage",
                                    (),
                                    {
                                        "input_tokens": input_tokens,
                                        "output_tokens": output_tokens,
                                        "prompt_tokens": input_tokens,
                                        "completion_tokens": output_tokens,
                                    },
                                )()

                    mock_result = MockResult(
                        self.response_id, self.response_model, self.service_tier, self.input_tokens, self.output_tokens
                    )

                    self.instrumentor._record_metrics(
                        operation_type="responses",
                        duration=duration,
                        result=mock_result,
                        span_attributes=span_attributes,
                    )

                    # End span with proper status
                    if self.span.span_instance.is_recording:
                        self.span.span_instance.set_status(
                            # pyright: ignore [reportPossiblyUnboundVariable]
                            StatusCode.OK
                        )
                        self.span.span_instance.end()
                    self.span_ended = True

            def __aiter__(self):
                return self

            async def __anext__(self):
                try:
                    chunk = await self.stream_async_iter.__anext__()
                    # Process chunk to accumulate data and maintain API compatibility
                    self.process_chunk(chunk)
                    # Also maintain backward compatibility with old accumulated_content
                    if hasattr(chunk, "output") and chunk.output:
                        self.accumulated_content.append(str(chunk.output))
                    elif hasattr(chunk, "delta") and isinstance(chunk.delta, str):
                        self.accumulated_content.append(chunk.delta)
                    return chunk
                except StopAsyncIteration:
                    # Stream is finished, perform cleanup
                    self.cleanup()
                    raise
                except Exception as e:
                    # Error occurred, record metrics and set error status
                    if not self.span_ended:
                        duration = time.time() - self.start_time
                        span_attributes = {
                            "gen_ai.request.model": self.model,
                            "server.address": self.server_address,
                            "server.port": self.port,
                        }
                        self.instrumentor._record_metrics(
                            operation_type="responses",
                            duration=duration,
                            result=None,
                            span_attributes=span_attributes,
                            error_type=str(type(e).__name__),
                        )
                        if self.span.span_instance.is_recording:
                            self.span.span_instance.set_status(
                                # pyright: ignore [reportPossiblyUnboundVariable]
                                StatusCode.ERROR,
                                str(e),
                            )
                            self.span.span_instance.record_exception(e)
                            self.span.span_instance.end()
                        self.span_ended = True
                    raise

            def _finalize_span(self):
                """Finalize the span with accumulated content and end it."""
                if not self.span_ended:
                    duration = time.time() - self.start_time
                    span_attributes = {
                        "gen_ai.request.model": self.model,
                        "server.address": self.server_address,
                        "server.port": self.port,
                    }
                    self.instrumentor._record_metrics(
                        operation_type="responses",
                        duration=duration,
                        result=None,
                        span_attributes=span_attributes,
                    )

                    if self.span.span_instance.is_recording:
                        # Note: For streaming responses, response metadata like tokens, finish_reasons
                        # are typically not available in individual chunks, so we focus on content.

                        if self.accumulated_content:
                            full_content = "".join(self.accumulated_content)
                            self.instrumentor._add_message_event(
                                self.span,
                                role="assistant",
                                content=full_content,
                                conversation_id=self.conversation_id,
                            )
                        self.span.span_instance.set_status(
                            # pyright: ignore [reportPossiblyUnboundVariable]
                            StatusCode.OK
                        )
                        self.span.span_instance.end()
                    self.span_ended = True

            async def __aenter__(self):
                return self

            async def __aexit__(self, exc_type, exc_val, exc_tb):
                try:
                    self.cleanup()
                except Exception:
                    pass  # Don't let cleanup exceptions mask the original exception
                return False

        return AsyncStreamWrapper(
            stream, span, conversation_id, self, start_time, operation_name, server_address, port, model
        )

    def start_create_conversation_span(
        self,
        server_address: Optional[str] = None,
        port: Optional[int] = None,
    ) -> "Optional[AbstractSpan]":
        """Start a span for create conversation API call."""
        span = start_span(
            operation_name=OperationName.CREATE_CONVERSATION,
            server_address=server_address,
            port=port,
            span_name=OperationName.CREATE_CONVERSATION.value,
            gen_ai_provider=AZURE_OPENAI_SYSTEM,
        )

        if span and span.span_instance.is_recording:
            self._set_span_attribute_safe(span, GEN_AI_OPERATION_NAME, OperationName.CREATE_CONVERSATION.value)

        return span

    def _create_conversations_span_from_parameters(self, *args, **kwargs):  # pylint: disable=unused-argument
        """Extract parameters and create span for conversations API tracing."""
        # Extract client from args (first argument)
        client = args[0] if args else None
        server_address, port = self._extract_server_info_from_client(client)

        # Create and return the span
        return self.start_create_conversation_span(
            server_address=server_address,
            port=port,
        )

    def trace_conversations_create(self, function, *args, **kwargs):
        """Trace synchronous conversations.create calls."""
        span = self._create_conversations_span_from_parameters(*args, **kwargs)

        # Extract parameters for metrics
        server_address, port = self._extract_server_info_from_client(args[0] if args else None)
        operation_name = "create_conversation"

        start_time = time.time()

        if span is None:
            # Still record metrics even without spans
            try:
                result = function(*args, **kwargs)
                duration = time.time() - start_time
                span_attributes = {
                    "server.address": server_address,
                    "server.port": port,
                }
                self._record_metrics(
                    operation_type="conversation",
                    duration=duration,
                    result=result,
                    span_attributes=span_attributes,
                )
                return result
            except Exception as e:
                duration = time.time() - start_time
                span_attributes = {
                    "server.address": server_address,
                    "server.port": port,
                }
                self._record_metrics(
                    operation_type="conversation",
                    duration=duration,
                    result=None,
                    span_attributes=span_attributes,
                    error_type=str(type(e).__name__),
                )
                raise

        with span:
            try:
                result = function(*args, **kwargs)
                duration = time.time() - start_time

                # Extract and set conversation attributes
                self._extract_conversation_attributes(span, result)

                # Record metrics using new dedicated method
                span_attributes = {
                    "server.address": server_address,
                    "server.port": port,
                }
                self._record_metrics(
                    operation_type="conversation",
                    duration=duration,
                    result=result,
                    span_attributes=span_attributes,
                )

                return result
            except Exception as e:
                duration = time.time() - start_time
                span_attributes = {
                    "server.address": server_address,
                    "server.port": port,
                }
                self._record_metrics(
                    operation_type="conversation",
                    duration=duration,
                    result=None,
                    span_attributes=span_attributes,
                    error_type=str(type(e).__name__),
                )
                span.span_instance.set_status(
                    # pyright: ignore [reportPossiblyUnboundVariable]
                    StatusCode.ERROR,
                    str(e),
                )
                span.span_instance.record_exception(e)
                raise

    async def trace_conversations_create_async(self, function, *args, **kwargs):
        """Trace asynchronous conversations.create calls."""
        span = self._create_conversations_span_from_parameters(*args, **kwargs)

        # Extract parameters for metrics
        server_address, port = self._extract_server_info_from_client(args[0] if args else None)
        operation_name = "create_conversation"

        start_time = time.time()

        if span is None:
            # Still record metrics even without spans
            try:
                result = await function(*args, **kwargs)
                duration = time.time() - start_time
                span_attributes = {
                    "server.address": server_address,
                    "server.port": port,
                }
                self._record_metrics(
                    operation_type="conversation",
                    duration=duration,
                    result=result,
                    span_attributes=span_attributes,
                )
                return result
            except Exception as e:
                duration = time.time() - start_time
                span_attributes = {
                    "server.address": server_address,
                    "server.port": port,
                }
                self._record_metrics(
                    operation_type="conversation",
                    duration=duration,
                    result=None,
                    span_attributes=span_attributes,
                    error_type=str(type(e).__name__),
                )
                raise

        with span:
            try:
                result = await function(*args, **kwargs)
                duration = time.time() - start_time

                # Extract and set conversation attributes
                self._extract_conversation_attributes(span, result)

                # Record metrics using new dedicated method
                span_attributes = {
                    "server.address": server_address,
                    "server.port": port,
                }
                self._record_metrics(
                    operation_type="conversation",
                    duration=duration,
                    result=result,
                    span_attributes=span_attributes,
                )

                return result
            except Exception as e:
                duration = time.time() - start_time
                span_attributes = {
                    "server.address": server_address,
                    "server.port": port,
                }
                self._record_metrics(
                    operation_type="conversation",
                    duration=duration,
                    result=None,
                    span_attributes=span_attributes,
                    error_type=str(type(e).__name__),
                )
                span.span_instance.set_status(
                    # pyright: ignore [reportPossiblyUnboundVariable]
                    StatusCode.ERROR,
                    str(e),
                )
                span.span_instance.record_exception(e)
                raise

    def start_list_conversation_items_span(
        self,
        server_address: Optional[str] = None,
        port: Optional[int] = None,
        conversation_id: Optional[str] = None,
    ) -> "Optional[AbstractSpan]":
        """Start a span for list conversation items API call."""
        span = start_span(
            operation_name=OperationName.LIST_CONVERSATION_ITEMS,
            server_address=server_address,
            port=port,
            span_name=OperationName.LIST_CONVERSATION_ITEMS.value,
            gen_ai_provider=AZURE_OPENAI_SYSTEM,
        )

        if span and span.span_instance.is_recording:
            # Set operation name attribute (start_span doesn't set this automatically)
            self._set_attributes(
                span,
                (GEN_AI_OPERATION_NAME, OperationName.LIST_CONVERSATION_ITEMS.value),
            )

            # Set conversation-specific attributes that start_span doesn't handle
            # Note: server_address is already set by start_span, so we don't need to set it again
            self._set_span_attribute_safe(span, "gen_ai.conversation.id", conversation_id)

        return span

    def _add_conversation_item_event(
        self,
        span: "AbstractSpan",
        item: Any,
    ) -> None:
        """Add a conversation item event to the span."""
        if not span or not span.span_instance.is_recording:
            return

        # Extract basic item information
        item_id = getattr(item, "id", None)
        item_type = getattr(item, "type", "unknown")
        role = getattr(item, "role", "unknown")

        # Create event attributes
        event_attributes = {
            GEN_AI_PROVIDER_NAME: AZURE_OPENAI_SYSTEM,
            "gen_ai.conversation.item.id": item_id,
            "gen_ai.conversation.item.type": item_type,
            "gen_ai.conversation.item.role": role,
        }

        # Create event body with the same JSON format as responses.create
        event_body: Dict[str, Any] = {"role": role}

        # Add content if content recording is enabled
        if _trace_responses_content and hasattr(item, "content") and item.content:
            content_list = []
            for content_item in item.content:
                if hasattr(content_item, "type") and content_item.type == "input_text":
                    if hasattr(content_item, "text"):
                        content_list.append(content_item.text)
                elif hasattr(content_item, "type") and content_item.type == "output_text":
                    if hasattr(content_item, "text"):
                        content_list.append(content_item.text)
                elif hasattr(content_item, "type") and content_item.type == "text":
                    if hasattr(content_item, "text"):
                        content_list.append(content_item.text)

            if content_list:
                event_body["content"] = " ".join(content_list)

        # Use JSON format for event content (consistent with responses.create)
        event_attributes["gen_ai.event.content"] = json.dumps(event_body, ensure_ascii=False)

        # Determine event name based on role
        if role == "assistant":
            event_name = "gen_ai.assistant.message"
        elif role == "user":
            event_name = "gen_ai.user.message"
        else:
            event_name = "gen_ai.conversation.item"

        span.span_instance.add_event(name=event_name, attributes=event_attributes)

    def _wrap_conversation_items_list(
        self,
        result,
        span: Optional["AbstractSpan"],
        start_time: float,
        operation_name: str,
        server_address: Optional[str],
        port: Optional[int],
    ):
        """Wrap the conversation items list result to add events for each item."""

        class ItemsWrapper:
            def __init__(self, items_result, span, instrumentor, start_time, operation_name, server_address, port):
                self.items_result = items_result
                self.span = span
                self.instrumentor = instrumentor
                self.start_time = start_time
                self.operation_name = operation_name
                self.server_address = server_address
                self.port = port

            def __iter__(self):
                # For synchronous iteration
                try:
                    for item in self.items_result:
                        if self.span:
                            self.instrumentor._add_conversation_item_event(self.span, item)
                        yield item

                    # Record metrics when iteration is complete
                    duration = time.time() - self.start_time
                    span_attributes = {
                        "server.address": self.server_address,
                        "server.port": self.port,
                    }
                    self.instrumentor._record_metrics(
                        operation_type="conversation_items",
                        duration=duration,
                        result=None,
                        span_attributes=span_attributes,
                    )

                    # End span when iteration is complete
                    if self.span:
                        self.span.span_instance.set_status(
                            # pyright: ignore [reportPossiblyUnboundVariable]
                            StatusCode.OK
                        )
                        self.span.span_instance.end()
                except Exception as e:
                    # Record metrics for error case
                    duration = time.time() - self.start_time
                    span_attributes = {
                        "server.address": self.server_address,
                        "server.port": self.port,
                    }
                    self.instrumentor._record_metrics(
                        operation_type="conversation_items",
                        duration=duration,
                        result=None,
                        span_attributes=span_attributes,
                        error_type=str(type(e).__name__),
                    )

                    if self.span:
                        self.span.span_instance.set_status(
                            # pyright: ignore [reportPossiblyUnboundVariable]
                            StatusCode.ERROR,
                            str(e),
                        )
                        self.span.span_instance.record_exception(e)
                        self.span.span_instance.end()
                    raise

            async def __aiter__(self):
                # For asynchronous iteration
                try:
                    async for item in self.items_result:
                        if self.span:
                            self.instrumentor._add_conversation_item_event(self.span, item)
                        yield item

                    # Record metrics when iteration is complete
                    duration = time.time() - self.start_time
                    span_attributes = {
                        "server.address": self.server_address,
                        "server.port": self.port,
                    }
                    self.instrumentor._record_metrics(
                        operation_type="conversation_items",
                        duration=duration,
                        result=None,
                        span_attributes=span_attributes,
                    )

                    # End span when iteration is complete
                    if self.span:
                        self.span.span_instance.set_status(
                            # pyright: ignore [reportPossiblyUnboundVariable]
                            StatusCode.OK
                        )
                        self.span.span_instance.end()
                except Exception as e:
                    # Record metrics for error case
                    duration = time.time() - self.start_time
                    span_attributes = {
                        "server.address": self.server_address,
                        "server.port": self.port,
                    }
                    self.instrumentor._record_metrics(
                        operation_type="conversation_items",
                        duration=duration,
                        result=None,
                        span_attributes=span_attributes,
                        error_type=str(type(e).__name__),
                    )

                    if self.span:
                        self.span.span_instance.set_status(
                            # pyright: ignore [reportPossiblyUnboundVariable]
                            StatusCode.ERROR,
                            str(e),
                        )
                        self.span.span_instance.record_exception(e)
                        self.span.span_instance.end()
                    raise

            def __getattr__(self, name):
                # Delegate other attributes to the original result
                return getattr(self.items_result, name)

        return ItemsWrapper(result, span, self, start_time, operation_name, server_address, port)

    def _create_list_conversation_items_span_from_parameters(self, *args, **kwargs):
        """Extract parameters and create span for list conversation items API tracing."""
        # Extract client from args (first argument)
        client = args[0] if args else None
        server_address, port = self._extract_server_info_from_client(client)

        # Extract conversation_id from kwargs
        conversation_id = kwargs.get("conversation_id")

        # Create and return the span
        return self.start_list_conversation_items_span(
            server_address=server_address,
            port=port,
            conversation_id=conversation_id,
        )

    def trace_list_conversation_items(self, function, *args, **kwargs):
        """Trace synchronous conversations.items.list calls."""
        span = self._create_list_conversation_items_span_from_parameters(*args, **kwargs)

        # Extract parameters for metrics
        server_address, port = self._extract_server_info_from_client(args[0] if args else None)
        operation_name = "list_conversation_items"

        start_time = time.time()

        if span is None:
            # Still record metrics even without spans
            try:
                result = function(*args, **kwargs)
                # For list operations, we can't measure duration until iteration is complete
                # So we'll record metrics in the wrapper or during iteration
                return self._wrap_conversation_items_list(
                    result, None, start_time, operation_name, server_address, port
                )
            except Exception as e:
                duration = time.time() - start_time
                span_attributes = {
                    "server.address": server_address,
                    "server.port": port,
                }
                self._record_metrics(
                    operation_type="conversation_items",
                    duration=duration,
                    result=None,
                    span_attributes=span_attributes,
                    error_type=str(type(e).__name__),
                )
                raise

        # Don't use context manager since we need the span to stay open during iteration
        try:
            result = function(*args, **kwargs)

            # Extract and set conversation items attributes
            self._extract_conversation_items_attributes(span, result, args, kwargs)

            # Wrap the result to add events during iteration and handle span ending
            wrapped_result = self._wrap_conversation_items_list(
                result, span, start_time, operation_name, server_address, port
            )

            return wrapped_result

        except Exception as e:
            duration = time.time() - start_time
            span_attributes = {
                "server.address": server_address,
                "server.port": port,
            }
            self._record_metrics(
                operation_type="conversation_items",
                duration=duration,
                result=None,
                span_attributes=span_attributes,
                error_type=str(type(e).__name__),
            )
            # pyright: ignore [reportPossiblyUnboundVariable]
            span.span_instance.set_status(StatusCode.ERROR, str(e))
            span.span_instance.record_exception(e)
            span.span_instance.end()
            raise

    async def trace_list_conversation_items_async(self, function, *args, **kwargs):
        """Trace asynchronous conversations.items.list calls."""
        span = self._create_list_conversation_items_span_from_parameters(*args, **kwargs)

        # Extract parameters for metrics
        server_address, port = self._extract_server_info_from_client(args[0] if args else None)
        operation_name = "list_conversation_items"

        start_time = time.time()

        if span is None:
            # Still record metrics even without spans
            try:
                result = await function(*args, **kwargs)
                # For list operations, we can't measure duration until iteration is complete
                # So we'll record metrics in the wrapper or during iteration
                return self._wrap_conversation_items_list(
                    result, None, start_time, operation_name, server_address, port
                )
            except Exception as e:
                duration = time.time() - start_time
                span_attributes = {
                    "server.address": server_address,
                    "server.port": port,
                }
                self._record_metrics(
                    operation_type="conversation_items",
                    duration=duration,
                    result=None,
                    span_attributes=span_attributes,
                    error_type=str(type(e).__name__),
                )
                raise

        # Don't use context manager since we need the span to stay open during iteration
        try:
            result = await function(*args, **kwargs)

            # Extract and set conversation items attributes
            self._extract_conversation_items_attributes(span, result, args, kwargs)

            # Wrap the result to add events during iteration and handle span ending
            wrapped_result = self._wrap_conversation_items_list(
                result, span, start_time, operation_name, server_address, port
            )

            return wrapped_result

        except Exception as e:
            duration = time.time() - start_time
            span_attributes = {
                "server.address": server_address,
                "server.port": port,
            }
            self._record_metrics(
                operation_type="conversation_items",
                duration=duration,
                result=None,
                span_attributes=span_attributes,
                error_type=str(type(e).__name__),
            )
            # pyright: ignore [reportPossiblyUnboundVariable]
            span.span_instance.set_status(StatusCode.ERROR, str(e))
            span.span_instance.record_exception(e)
            span.span_instance.end()
            raise

    def _trace_sync_function(
        self,
        function: Callable,
        *,
        _args_to_ignore: Optional[List[str]] = None,
        _trace_type=TraceType.RESPONSES,
        _name: Optional[str] = None,
    ) -> Callable:
        """
        Decorator that adds tracing to a synchronous function.

        :param function: The function to be traced.
        :type function: Callable
        :param args_to_ignore: A list of argument names to be ignored in the trace. Defaults to None.
        :type: args_to_ignore: [List[str]], optional
        :param trace_type: The type of the trace. Defaults to TraceType.RESPONSES.
        :type trace_type: TraceType, optional
        :param name: The name of the trace, will set to func name if not provided.
        :type name: str, optional
        :return: The traced function.
        :rtype: Callable
        """

        @functools.wraps(function)
        def inner(*args, **kwargs):
            if _name == "create" and _trace_type == TraceType.RESPONSES:
                return self.trace_responses_create(function, *args, **kwargs)
            if _name == "create" and _trace_type == TraceType.CONVERSATIONS:
                return self.trace_conversations_create(function, *args, **kwargs)
            if _name == "list" and _trace_type == TraceType.CONVERSATIONS:
                return self.trace_list_conversation_items(function, *args, **kwargs)
            # pylint: disable=no-else-return
            else:  # pylint: disable=no-else-return
                return function(*args, **kwargs)

        return inner

    def _trace_async_function(
        self,
        function: Callable,
        *,
        _args_to_ignore: Optional[List[str]] = None,
        _trace_type=TraceType.RESPONSES,
        _name: Optional[str] = None,
    ) -> Callable:
        """
        Decorator that adds tracing to an asynchronous function.

        :param function: The function to be traced.
        :type function: Callable
        :param args_to_ignore: A list of argument names to be ignored in the trace. Defaults to None.
        :type: args_to_ignore: [List[str]], optional
        :param trace_type: The type of the trace. Defaults to TraceType.RESPONSES.
        :type trace_type: TraceType, optional
        :param name: The name of the trace, will set to func name if not provided.
        :type name: str, optional
        :return: The traced function.
        :rtype: Callable
        """

        @functools.wraps(function)
        async def inner(*args, **kwargs):
            if _name == "create" and _trace_type == TraceType.RESPONSES:
                return await self.trace_responses_create_async(function, *args, **kwargs)
            if _name == "create" and _trace_type == TraceType.CONVERSATIONS:
                return await self.trace_conversations_create_async(function, *args, **kwargs)
            if _name == "list" and _trace_type == TraceType.CONVERSATIONS:
                return await self.trace_list_conversation_items_async(function, *args, **kwargs)
            # pylint: disable=no-else-return
            else:  # pylint: disable=no-else-return
                return await function(*args, **kwargs)

        return inner

    def _inject_async(self, f, _trace_type, _name):
        wrapper_fun = self._trace_async_function(f, _trace_type=_trace_type, _name=_name)
        wrapper_fun._original = f  # pylint: disable=protected-access # pyright: ignore [reportFunctionMemberAccess]
        return wrapper_fun

    def _inject_sync(self, f, _trace_type, _name):
        wrapper_fun = self._trace_sync_function(f, _trace_type=_trace_type, _name=_name)
        wrapper_fun._original = f  # pylint: disable=protected-access # pyright: ignore [reportFunctionMemberAccess]
        return wrapper_fun

    def _responses_apis(self):
        sync_apis = []
        async_apis = []

        try:
            import openai.resources.responses as responses_module

            if hasattr(responses_module, "Responses"):
                sync_apis.append(
                    (
                        responses_module.Responses,
                        "create",
                        TraceType.RESPONSES,
                        self._inject_sync,
                        "create",
                    )
                )
        except ImportError:
            pass

        try:
            import openai.resources.responses as responses_module

            if hasattr(responses_module, "AsyncResponses"):
                async_apis.append(
                    (
                        responses_module.AsyncResponses,
                        "create",
                        TraceType.RESPONSES,
                        self._inject_async,
                        "create",
                    )
                )
        except ImportError:
            pass

        return sync_apis, async_apis

    def _conversations_apis(self):
        sync_apis = []
        async_apis = []

        try:
            from openai.resources.conversations.conversations import Conversations

            sync_apis.append(
                (
                    Conversations,
                    "create",
                    TraceType.CONVERSATIONS,
                    self._inject_sync,
                    "create",
                )
            )
        except ImportError:
            pass

        try:
            from openai.resources.conversations.conversations import AsyncConversations

            async_apis.append(
                (
                    AsyncConversations,
                    "create",
                    TraceType.CONVERSATIONS,
                    self._inject_async,
                    "create",
                )
            )
        except ImportError:
            pass

        # Add conversation items APIs
        try:
            from openai.resources.conversations.items import Items

            sync_apis.append(
                (
                    Items,
                    "list",
                    TraceType.CONVERSATIONS,
                    self._inject_sync,
                    "list",
                )
            )
        except ImportError:
            pass

        try:
            from openai.resources.conversations.items import AsyncItems

            async_apis.append(
                (
                    AsyncItems,
                    "list",
                    TraceType.CONVERSATIONS,
                    self._inject_async,
                    "list",
                )
            )
        except ImportError:
            pass

        return sync_apis, async_apis

    def _responses_api_list(self):
        sync_apis, async_apis = self._responses_apis()
        yield from sync_apis
        yield from async_apis

    def _conversations_api_list(self):
        sync_apis, async_apis = self._conversations_apis()
        yield from sync_apis
        yield from async_apis

    def _all_api_list(self):
        yield from self._responses_api_list()
        yield from self._conversations_api_list()

    def _generate_api_and_injector(self, apis):
        yield from apis

    def _available_responses_apis_and_injectors(self):
        """
        Generates a sequence of tuples containing Responses and Conversations API classes, method names, and
        corresponding injector functions.

        :return: A generator yielding tuples.
        :rtype: tuple
        """
        yield from self._generate_api_and_injector(self._all_api_list())

    def _instrument_responses(self, enable_content_tracing: bool = False):
        """This function modifies the methods of the Responses API classes to
        inject logic before calling the original methods.
        The original methods are stored as _original attributes of the methods.

        :param enable_content_tracing: Indicates whether tracing of message content should be enabled.
                                    This also controls whether function call tool function names,
                                    parameter names and parameter values are traced.
        :type enable_content_tracing: bool
        """
        # pylint: disable=W0603
        global _responses_traces_enabled
        global _trace_responses_content
        if _responses_traces_enabled:
            return

        _responses_traces_enabled = True
        _trace_responses_content = enable_content_tracing

        # Initialize metrics instruments
        self._initialize_metrics()

        for (
            api,
            method,
            trace_type,
            injector,
            name,
        ) in self._available_responses_apis_and_injectors():
            try:
                setattr(api, method, injector(getattr(api, method), trace_type, name))
            except (AttributeError, ImportError) as e:
                logger.debug(f"Could not instrument {api.__name__}.{method}: {e}")

    def _uninstrument_responses(self):
        global _responses_traces_enabled
        global _trace_responses_content
        if not _responses_traces_enabled:
            return

        _responses_traces_enabled = False
        _trace_responses_content = False
        for (
            api,
            method,
            trace_type,
            injector,
            name,
        ) in self._available_responses_apis_and_injectors():
            try:
                original_method = getattr(getattr(api, method), "_original", None)
                if original_method:
                    setattr(api, method, original_method)
            except (AttributeError, ImportError):
                pass

    def _is_instrumented(self):
        global _responses_traces_enabled
        return _responses_traces_enabled

    def _set_enable_content_recording(self, enable_content_recording: bool = False) -> None:
        global _trace_responses_content
        _trace_responses_content = enable_content_recording

    def _is_content_recording_enabled(self) -> bool:
        global _trace_responses_content
        return _trace_responses_content

    def record_error(self, span, exc):
        # pyright: ignore [reportPossiblyUnboundVariable]
        span.span_instance.set_status(StatusCode.ERROR, str(exc))
        span.span_instance.record_exception(exc)
